



saludo = "Hola!";
pregunta = " Buenos dias";
respuesta = " Me alegra! que pases un exelente resto de dia "
respuesta2 = " Que triste, espero te recuperes pronto!  "
respuesta3 = "Muy Bien!! Me alegra!, que pases un exelente resto de dia"

frase = saludo + pregunta;

 
alert(frase);

document.write(frase);

let tuNombre = prompt("Cual es tu nombre ?");

let nombre = prompt("Como estas el dia de hoy "+tuNombre);


if (nombre == "Bien" || nombre == "bien" ){
alert (respuesta);

}
else if (nombre == "Mal" || nombre == "mal" ){
    alert (respuesta2);
}

else if (nombre == "Exelente" || nombre == "exelente" ){
    alert (respuesta3);
}

else {
    alert ("Ok, que pases un exelente resto de dia");

}


/*AHORA UN EJEMPLO CON FUNCIONES PARA QUE LA MISMA PREGUNTA 
SALGA EN 2 VECES SIN NECESIDAD DE REPETIR EL MISMO CODIGO*/

alert("Para ingresar al sistema digita la instruccion de bot en dos veces")

function noRobot(){

bot = prompt("Hola, "+tuNombre+" soy newBotIdentity, y necesito que escribas mi nombre, de lo contrario no podras acceder al sistema");


for (let i = 0; i<1000000; i++){

    if (bot== "newBotIdentity"){
break;
}
else if (bot =! "" ){

    alert(i+" Acceso denegado")

}
}
}

noRobot(); //Si quiero que se repita en 5 veces anoto la funcion "noRobot();" en 6 veces
noRobot(); /*CON ESTE EJEMPLO QUEDA CLARO QUE LA FUNCION "noRobot();" NOS 
AHORRA LINEAS DE CODIGO EN CASO DE REQUERIR DE NUEVO LA MISMA SOLICITUD...*/ 


