﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Memorizando;

public class Program
{
    public static int numero { get; private set; }

    public static void Main(string[] args)
    {
        Console.WriteLine("");
       //----------------------------------------
        Console.WriteLine("PRIMER CONSTRUCTOR: ");
//------------------------------------------------------------------------------

// 2 Ejemplos de invocacion al costructor:

var GrupoDeFrutas  = new Frutas(){Naranjas = "Naranjas del Valle", Manzanas = "Manzanas la Cosecha", Uvas = " Uvas la Isabella" };

//1. 

Console.WriteLine(GrupoDeFrutas.Naranjas + ", " + GrupoDeFrutas.Manzanas + ", " + GrupoDeFrutas.Uvas);


Console.WriteLine();

//2.
Frutas GrupoDeFrutas2 = GrupoDeFrutas;
GrupoDeFrutas2.Naranjas = "Naranjas de Occidente" + ", " + GrupoDeFrutas.Manzanas;

Console.WriteLine(GrupoDeFrutas2.Naranjas);

//-----------------------------------------------------------------------------



Console.WriteLine("");
Console.WriteLine("SEGUNDO CONSTRUCTOR: ");

//------------------------------------------------------------------------------

// 2 Ejemplos de invocacion al costructor:

var GrupoDeLegumbres = new Legumbres(){ Papas = "Papas Paramount", Platanos = "Platanos la Cosecha", Yuca = "Yuca Orizonte" };

//1.
//Clase     Nuevo objeto    Grupo al que pertenece

Console.WriteLine(GrupoDeLegumbres.Papas + ", "+ GrupoDeLegumbres.Platanos + ", "+ GrupoDeLegumbres.Papas);


Console.WriteLine("");

//2.

//Clase     Nuevo objeto  Grupo Constructor al que pertenece 
Legumbres GrupoDeLegumbres2 = GrupoDeLegumbres;

GrupoDeLegumbres.Papas = "Papas La Sabaneta";

Console.WriteLine(GrupoDeLegumbres2.Papas);

//------------------------------------------------------------------------------

Console.WriteLine("");


Console.WriteLine("TERCER CONSTRUCTOR: ");
Console.WriteLine();

// 3 Ejemplos de invocacion al costructor:

Vendedores Empresa = new Vendedores(){ Gerente = "Santiagoth (Gerente)" , Jefe = "Santiagoth (Jefe)", Vendedor = " Santiagoth (Vendedor)" };

//1. 
Console.WriteLine(Empresa.Gerente + ", " + Empresa.Jefe + ", " + Empresa.Vendedor );



Console.WriteLine("");


//2. 

Vendedores Empresa2 = Empresa;
Empresa2.Gerente = "Augusto (Gerente Sustituto)";

Console.WriteLine(Empresa2.Gerente + ", " + Empresa.Jefe + ", " + Empresa.Vendedor );


Console.WriteLine("");


//3. 

Vendedores Empresa3 = Empresa;

Empresa3.Gerente = "Andres (Gerente sustituto 3)";
Empresa2.Vendedor = "Augusto (Vendedor)";

Console.WriteLine(Empresa2.Gerente + ", " + Empresa.Jefe + ", " + Empresa2.Vendedor );

//------------------------------------------------------------------------------


//NUMEROS PRIMOS...

Console.WriteLine("");
Console.WriteLine("VECTORES:");
Console.WriteLine("");

int [] Santiagoth = new int [6];

Santiagoth[0] = 1;
Santiagoth[1] = 2;
Santiagoth[2] = 3;
Santiagoth[3] = 4;
Santiagoth[4] = 5;
Santiagoth[5] = 6;

Console.Write("[ CHAT ] ");
Console.WriteLine("");
Console.WriteLine(Santiagoth[0]+". Hello Friend");
Console.WriteLine("");
Console.WriteLine(Santiagoth[1]+". Hello!");
Console.WriteLine("");
Console.WriteLine(Santiagoth[0]+". My name is Santiagoth, what is your name ? ");
Console.WriteLine("");
Console.WriteLine(Santiagoth[1]+". Yes, my name is Sandra ");
Console.WriteLine("");
Console.WriteLine(Santiagoth[2]+". My name is Rina ");
Console.WriteLine("");
Console.WriteLine(Santiagoth[3]+". My name is Sandro !! ");
Console.WriteLine("");
Console.WriteLine(Santiagoth[4]+". My name is Isabella  ");
Console.WriteLine("");
Console.WriteLine(Santiagoth[5]+". My name is Robert ");
Console.WriteLine("");

Console.WriteLine("[ VECTORES ] ");
Console.WriteLine("");
Console.WriteLine("Ciclo For:  ");
Console.WriteLine("");


int [] NumSantiagoth = new int[11];

for (int i=1;i< NumSantiagoth.Length;i++){

    Console.Write("[" +i+"] ");
    

    }
    //Pedir Notas por teclado: 
Console.WriteLine("");
Console.WriteLine("Pedir Notas por teclado y promedio: ");
Console.WriteLine("");
    


double[] notas = new double[3]; //Vector
double promedio = 0;
//-----------------------------------------------------------------------

for (int i2=0; i2<notas.Length;i2++){

    Console.Write($"Ingrese nota: {i2+1}: "); // El "$" mas el "{i2+1}" es para realizar un contador numerico en cada pregunta
    
    double nota = double.Parse(Console.ReadLine()); //Lector de teclado

notas[i2] = nota; // Nuevo Objeto 

//-----------------------------------------

promedio += notas[i2];      // Operacion 1
}
promedio /= notas.Length; // Operacion 2

Console.WriteLine("El promedio es: " + promedio);
Console.WriteLine("");




//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------


//CALCULADORA 1


    Console.WriteLine("");
    Console.WriteLine("Calculadora");
    Console.WriteLine("");


string[] operaciones = new string[5];

int opercion = 0,  numero1=0, numero2=0, resultado =0; 


Console.WriteLine("Ingrese la operacion que desea realizar  ");
Console.WriteLine(" ");
Console.WriteLine("1. Suma 2, Resta 3. Multiplicacion 4. Division ");
int operacion = int.Parse(Console.ReadLine());  //Lector de teclado
Console.WriteLine("Ingrese Numero 1");
numero1 = int.Parse(Console.ReadLine());
Console.WriteLine("Ingrese Numero 2");
numero2 = int.Parse(Console.ReadLine());


switch (operacion) {

// En caso de que nummero1 + numero2

    case 1: // "case" se tiene que cerrar con "break"

    resultado = numero1 + numero2;

operaciones[0] = numero1 + "";
operaciones[1] = " + ";
operaciones[2] = numero2 + "";
operaciones[3] = " = ";
operaciones[4] = resultado + "";

break;

// En caso de que nummero1 - numero2

    case 2: // "case" se tiene que cerrar con "break"

    resultado = numero1 - numero2;

operaciones[0] = numero1 + "";
operaciones[1] = " - ";
operaciones[2] = numero2 + "";
operaciones[3] = " = ";
operaciones[4] = resultado + "";

break;


// En caso de que nummero1 * numero2

    case 3: // "case" se tiene que cerrar con "break"

    resultado = numero1 * numero2;

operaciones[0] = numero1 + "";
operaciones[1] = " * ";
operaciones[2] = numero2 + "";
operaciones[3] = " = ";
operaciones[4] = resultado + "";

break;


// En caso de que nummero1 + numero2

    case 4: // "case" se tiene que cerrar con "break"

    resultado = numero1 / numero2;

operaciones[0] = numero1 + "";
operaciones[1] = " / ";
operaciones[2] = numero2 + "";
operaciones[3] = " = ";
operaciones[4] = resultado + "";

break;

//O sino por defecto = 1
   default:
   resultado = 0;
   break;
}

Console.WriteLine();
Console.WriteLine();
Console.WriteLine("El resultado de la operacion es: ");
Console.WriteLine("");

for ( int i = 0; i < operaciones.Length; i++){

Console.Write(operaciones[i]);
//Console.WriteLine("");

}
Console.WriteLine("");




//CALCULADORA 2


Console.WriteLine("");
Console.WriteLine("Calculadora 2");
Console.WriteLine("");

var proceso = new int[5];

proceso[3] = '='; //Declaraacion de resultado

var resultado2 = 0;

for (int i3=0; i3<proceso.Length-2;i3++){

if (i3%2 == 0)

{
Console.WriteLine("Digite un numero: ");
proceso[i3] = int.Parse(Console.ReadLine());

}

else

{
Console.WriteLine("Digite el proceso matematico (+ , - , * , /) ");
proceso[i3] = Console.ReadLine()[0];

}}

switch ((char) proceso[1]){

case '+':
resultado2 = proceso[0] + proceso[2];
break;
case '-':
resultado2 = proceso[0] - proceso[2];
break;
case '*':
resultado2 = proceso[0] + proceso[2];
break;
case '/':
resultado2 = proceso[0] + proceso[2];
break;

}



proceso[proceso.Length-1] = resultado2;
Console.WriteLine("El resultado es:" +  proceso[proceso.Length - 1]);



}



}


    



    

 












/* [ VECTOR ]  que imprime numeros pares:


int [] DivSantiagoth = new int[10];

for (int i2=1, cont=0;i2<=100;i2++){ // Truco de la " , "en este ciclo

    if (i2%2==0){

        DivSantiagoth[cont] = i2;

        
        Console.Write("[" + DivSantiagoth[cont]+"] ");
        cont++;
    }
}
    
Console.Write("");


Console.WriteLine("Hola");
//ALERTA ALERTA HACKER ALERTA!!! PELIGROSO ENEMIGO RODEANDO EL PERIMETRO PRIVADO


}

}






    









//Para que el program pida numero por consola: -->  int b = int.Parse(Console.ReadLine());

//Para que el program pida Nombre por consola: -->  string MiNombre = (Console.ReadLine());

                                             //-->  string numero = Console.ReadLine();
/* 

-----------------------------------------------------
| EJEMPLO PARA INGRESAR -- MATRICES -- POR TECLADO: |
-----------------------------------------------------


Console.WriteLine("Matriz de:");
            int a = int.Parse(Console.ReadLine());

            Console.WriteLine("Matriz por:");
            int b = int.Parse(Console.ReadLine());

            int[,] bidimencion;
            bidimencion = new int[a, b];

            Random numero = new Random();

            * Llenando de la matriz con numero aleatorios entre 1 y 100

            for (int i = 0; i < a; i++)
            {
                for (int j = 0; j < b; j++)
                {

                    bidimencion[i, j] = numero.Next(1, 100);
                }
            }
            Console.WriteLine("Impresion de la matriz");
         
          *  Impresion de la matriz

            for (int i = 0; i < a; i++)
            {
                for (int j = 0; j < b; j++)
                {
                    Console.Write(bidimencion[i, j]);
                    if (j + 1 == b) { Console.WriteLine(); } else { Console.Write(" - "); }
                }
            }
            Console.ReadKey(true);
        }
    }




--------------------------------------------------------------------
| EJEMPLO PARA SABER CUANTAS VOCALES HAY EN EL NOMBRE INGRESADO:   |
--------------------------------------------------------------------

float numeroFlotante = 0;
char letra = 'A';
//string MiNombre = "Santiagoth";
bool verdadero = true;


string MiNombre = (Console.ReadLine());

Console.WriteLine(" ");

MiNombre = MiNombre.ToLower();

for ( int i=0; i<MiNombre.Length; i++)
{
if (MiNombre[i] == 'a' || MiNombre[i] == 'e' || MiNombre[i] == 'i' || MiNombre[i] == 'o' || MiNombre[i] == 'u'){

numero++;

}
}

Console.WriteLine("El nombre tiene " + numero + " vocales");
Console.ReadKey();
}
}

----------------------------------------------------------
| ALGORITMO PARA IMPRIMIR LETRAS DE LA | A | a la | Z |  |
----------------------------------------------------------

for( char letra = 'A'; letra<='Z'; letra++){

Console.Write(letra + ", ");

Console.ReadKey();

}

--------------------------------------------------------------------------
| ALGORITMO PARA CONSULTAR CUANTAS CONSONANTES TIENE UN NOMBRE O PALABRA |
--------------------------------------------------------------------------


for( int letra = 65; letra<='Z'; letra++){

Console.Write((char)letra + ", ");

}
Console.Write("Digita tu nombre:  ");

var nombre = Console.ReadLine().ToLower();
 var contador = 0;


for (int i=0; i<nombre.Length; i++)

{
   
if(nombre[i] != 'a' && nombre[i]!= 'e' && nombre[i]!= 'i' && nombre[i]!= 'o' && nombre[i]!= 'u')

{

// var contador = 0;
contador++;

}

}
Console.WriteLine( " La cantidad de consonantes es: " + contador);

Console.ReadKey();
*/





