

namespace Memorizando
{
    public class Legumbres
    {
        
    

//NOTA: Si no se pone public la clase queda local o privada...

public string? Papas {get; set;} 

public string? Platanos {get; set;}

public string? Yuca {get; set;}




    }
}