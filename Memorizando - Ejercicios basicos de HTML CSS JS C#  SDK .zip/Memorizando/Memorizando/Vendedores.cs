using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Memorizando
{
    public class Vendedores
    {
        



        public string? Gerente {get; set;}
        
        public string? Jefe {get; set;}

        public string? Vendedor {get; set;}


    }
}