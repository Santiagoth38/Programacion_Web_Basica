

namespace Memorizando
{





    

    public class Frutas
    {
        

       public string? Naranjas {get; set;}

     public string?  Manzanas {get;set;}

     public string? Uvas {get;set;}


    }


        
    }
